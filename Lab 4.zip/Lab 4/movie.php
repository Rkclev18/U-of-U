<?php

if (isset( $_GET['id'] )) {
    $id = $_GET['id'];
    echo $id . '<br>';

    if ($id==1) {
        echo "Star Wars<br>";
    }else if ($id==2) {
        echo "Lord of the Rings<br>";
    }else{
        echo "Star Trek<br>";
    }
}
