<html>
	<head>
	</head>
	
	<body>
		<!--Example 11-6 -->
		8am-noon<input type="radio" name="time" value="1">
	    Noon-4pm<input type="radio" name="time" value="2" checked="checked">
        4pm-8pm<input type="radio" name="time" value="3">

        <!--Example 11-7 -->
         Vegetables
        <select name="veg" size="1">
	        <option value="Peas">Peas</option>
	        <option value="Beans">Beans</option>
	        <option value="Carrots">Carrots</option>
	        <option value="Cabbage">Cabbage</option>
	        <option value="Brocolli">Brocolli</option>
        </select>
	</body>
</html>


