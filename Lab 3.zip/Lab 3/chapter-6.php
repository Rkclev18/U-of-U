<?php

//Example 6-2

$paper[0] = "Copier";
$paper[1] = "Inkjet";
$paper[2] = "Laser";
$paper[3] = "Photo";
print_r($paper);
echo "<br>";

//Example 6-4

$paper['Copier'] = "Color and Multipurpose";
$paper['Inkjet'] = "Inkjet Printer";
$paper['Laser'] = "Laser Printer";
$paper['Photo'] = "Photographic Paper";
echo $paper['Laser'];
echo "<br>";
echo "<br>";

//Example 6-6

$paper = array("Copier","Inkjet","Laser","Photo");
$j =0;
echo count($paper);
echo "<br>";

foreach ($paper as $item){
	echo "$j: $item.<br>";
	++$j;
}

echo "<br>";

//Example 6-12

$temp = explode(' ', "PHP is a server-side scripting language designed primarily for web development but also used as a general-purpose programming language. Originally created by Rasmus Lerdorf in 1994,[5] the PHP reference implementation is now produced by The PHP Development Team.[6] PHP originally stood for Personal Home Page,[5] but it now stands for the recursive acronym PHP: Hypertext Preprocessor.[7]");

print_r($temp);

echo "<br>";

?>