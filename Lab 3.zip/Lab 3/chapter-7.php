<?php

//date function
echo date("l F jS, Y – g:ia", time());
echo '<br>';

//Example 7-4

$fh = fopen("testfile.txt", 'w') or die("Failed to create file");
$text = <<<_END
Line 1
Line 2
Line 3
_END;
  fwrite($fh, $text) or die("Could not write to file");
  fclose($fh);
  echo "File 'testfile.txt' written successfully";
  echo '<br>';

//Example 7-7

if (!copy('testfile.txt', 'testfile2.txt')) echo "Could not copy file";
else echo "File successfully copied to 'testfile2.txt'";
echo '<br>';


//Example 7-11

$fh   = fopen("testfile.txt", 'r+') or die("Failed to open file");
$text = fgets($fh);
fseek($fh, 0, SEEK_END);
fwrite($fh, "$text") or die("Could not write to file");
fclose($fh);
echo "File 'testfile.txt' successfully updated";
echo '<br>';

//Exercise 1

$fh = fopen("gap-retail-sales.csv", 'r+') or die("Failed to open file");

echo "<table>";

while (!feof($fh)) {
    $line = fgets($fh);
    $data = explode(",", $line);

    echo "<tr>";
    foreach ($data as $value) {
        echo "<td>" . htmlspecialchars($value) . "</td>";
    }
    echo "</tr>";
}

echo "</table>";

fclose($fh);
?>