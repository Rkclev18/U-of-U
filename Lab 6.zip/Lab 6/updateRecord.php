<?php

require_once  'login.php';

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die($conn->connect_error);

if(isset($_GET['isbn'])){
	
$isbn = $_GET['isbn'];	

$query = "SELECT * FROM classics2 where isbn=$isbn";

$result = $conn->query($query); 
if(!$result) die($conn->error);

$rows = $result->num_rows;

for($j=0; $j<$rows; $j++)
{
	//$result->data_seek($j); 
	$row = $result->fetch_array(MYSQLI_ASSOC); 
	
	$category = $row['category'];
	$A=$B=$C='';
	if($category=='Classic Fiction') $A = 'selected';
	if($category=='Non-Fiction') $B = 'selected';
	if($category=='Play') $C = 'selected';
echo <<<_END
	
	<form action='updateRecord.php' method='post'>

	<pre>
	
	Author: <input type='text' name='author' value='$row[author]'>
	Title: <input type='text' name='title' value='$row[title]'>
	Year: <input type='text' name='year' value='$row[year]'>
	ISBN: $row[isbn]	
	Category: <select name='category' id='category'>
		<option value='Classic Fiction' $A>Classic Fiction</option>
		<option value='Non-Fiction' $B>Non-Fiction</option>
		<option value='Play' $C>Play</option>
    </select>
	
	</pre>
	
		<input type='hidden' name='update' value='yes'>
		<input type='hidden' name='isbn' value='$row[isbn]'>
		<input type='submit' value='UPDATE RECORD'>	
	</form>
	
_END;

}

}


if(isset($_POST['update'])){
	
	$isbn = $_POST['isbn'];
	$author = $_POST['author'];
	$title = $_POST['title'];
	$category = $_POST['category'];
	$year = $_POST['year'];
	
	$query = "Update classics2 set author='$author', title='$title', category='$category', year='$year' where isbn = $isbn";
	
	$result = $conn->query($query); 
	if(!$result) die($conn->error);
	
	header("Location: viewRecord.php");
	
	
}

$conn->close();



?>