<?php

if(isset($_POST['username'])){
	$username = fix_string($_POST['username']); 
	$email = fix_string($_POST['email']);
	$password1 = fix_string($_POST['password1']);
	$password2 = fix_string($_POST['password2']);	
	
	$fail = validate_username($username);
	$fail = validate_email($email);
	$fail = validate_password1($password1);
	$fail = validate_password2($password2);
	$fail = compare_password($password1,$password2);
	
	
	if ($fail == ""){
		echo "Form data validated successfully<br>";
	}else{
		echo $fail. '<br>';
	}
	
}

function validate_username($string){
	return ($string == "") ? "No Username was entered.\n" : "";
}


function validate_email($string){
	return ($string == "") ? "No Email was entered.\n" : "";
}


function validate_password1($string){
	return ($string == "") ? "No Password1 was entered.\n" : "";
}


function validate_password2($string){
	return ($string == "") ? "No Password2 was entered.\n" : "";
}


function compare_password($pass1, $pass2){
	if($pass1==$pass2) return "";
	else return "Your Passwords do not match\n";
}


function fix_string($string){
	if (get_magic_quotes_gpc()) $string = stripslashes($string);
	return htmlentities ($string);
}
	
?>