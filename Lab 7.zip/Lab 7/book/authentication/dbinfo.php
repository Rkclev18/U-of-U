<?php

$hn='localhost:3306';
$db='publications';
$un='root';
$pw='';



?>