<?php

require_once 'dbinfo.php';
require_once 'checksession.php';

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

echo <<<_END
	<pre>
	<a href="addBook.php">Add Book</a>
	<a href="Logout.php">Logout</a>
	
_END;

$query="SELECT * FROM classics";
$result=$conn->query($query);
if(!$result) die ($conn->error);

$rows=$result->num_rows;
for($j=0; $j<$rows; $j++) {
	$result->data_seek($j);
	$row=$result->fetch_array(MYSQLI_BOTH);
	
	echo <<<_END
	<pre>
		ISBN $row[isbn];
		Author $row[author];
		Title $row[title];
		Category $row[category];
		Year $row[year];
	</pre>
	<form action="deleteBook.php" method="post">
	<input type="hidden" name="delete" value="yes">
	<input type="hidden" name="isbn" value="$row[isbn]">
	<input type="submit" value="DELETE RECORD">
	</form>
_END;
}

$result->close();
$conn->close();

function get_post($conn, $var) {
	return $conn->real_escape_string($_POST[$var]);
}



?>